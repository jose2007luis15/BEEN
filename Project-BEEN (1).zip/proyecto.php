<section class="content-section" id="proyecto">
            <div class="container px-4 px-lg-5">
                <div class="content-section-heading text-center">
                     <h2 class="mb-5">Nuestro Proyecto</h2>
                </div>
                <div class="row gx-0">
                     <div class="col-lg-6">
                        <a class="portfolio-item" href="#explicacion">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Interpretación</div>
                                    <p class="mb-0">Explicación sobre nuestra empresa.</p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/img/minecraft-4.jpg" alt="..." />
                        </a>
                    </div>
                     

                  
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Seguridad</div>
                                    <p class="mb-0">Explicación sobre nuestro proyecto a futuro respecto a la seguridad.</p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/img/minecraft-3.jpg" alt="..." />
                        </a>
                    </div>
                  
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Alcance del Sistema</div>
                                    <p class="mb-0">El sistema va a permitir:
                                      <li>Comprar de manera segura y facil.</li>
                                      <li>Va a permitir que otos usuarios vendan o compren sus productos.</li>
                                                                                                           
                                      <li>Va a permitir comprar por transacciones y de otras maneras de pago como la fifica y virtualva a permitir el desarrollo economico y social de nuestros cliente y nosotros.</li>
                                                                          <ul>
                                    <br>
                                    </ul>  
                                    </p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/img/minecraft-5.jpg" alt="..." />
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Objetivos</div>
                                    <p class="mb-0">
                                    <ul>
                                    <li></li>  
                                    <li></li>  
                                    <li></li>  
                                    </ul>
                                    
                                    </p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/img/minecraft-6.jpg" alt="..." />
                        </a>
                    </div>
                </div>
            </div>
        </section>