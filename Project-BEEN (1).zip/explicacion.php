<section class="content-section bg-danger fondo text-white" id="explicacion">
            <div class="container px-4 px-lg-5">
                <div class="content-section-heading text-center">
                     <h2 class="mb-5">Explicacion sobre el proyecto</h2>
                  
<h3>Nuestro proyecto se basa en la venta de 
    productos de diferentes usuarios, con respecto a la 
    satisfaccion y manejo facil de la empresa. Se tendra 
    en cuenta la calidad y mejora de los medios de pago y el 
    formato acerca de la empresa que se tiene en cuenta para 
    un futuro, para beneficiar a todo tipo de personas.</h3>
                </div>
                <div class="row gx-0">
                     <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div></p></div></p>
                                  
                                    <p class="mb-0">Descripción </p>
                                </div>
                            </div>
                        
                       
                        </a>
                    </div>
                     

                  
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2"></div>
                                    <p class="mb-0"> </p>
                                </div>
                            </div>
                        </a>
                    </div>
                                                       <ul>
                                    
                                      
                                    </ul>  
                                    </p>
                                </div>
                            </div>
                        
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2"></div>
                                    <p class="mb-0">
                                    <ul>
                                     
                                    </ul>
                                    
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>