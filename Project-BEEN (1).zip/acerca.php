        <section class="content-section bg-light" id="acerca">
            <div class="container px-4 px-lg-5 text-center">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-10">
                        <h2>¡BEEN es un futuro proyecto de emprendimiento!</h2>
                        <p class="lead mb-5">
                            Grado 10 de la Fé y Alegría Aures.
                            !
                          <br>Integrantes:
                          <br>Jose Luis Contreras Marsiglia
                          <br>David Sierra Higuita
                          <br>Sergio Bermudez (ac)
                          <br>Lider: Emanuel Angel Marin
                        </p>
                        <a class="btn btn-dark btn-xl" href="#page-top">regresar ⬆</a>
                    </div>
                </div>
            </div>
        </section>