<a class="menu-toggle rounded" href="#"><i class="fas fa-bars"></i></a>
        <nav id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand"><a href="#page-top">BEEN</a></li>
                <li class="sidebar-nav-item"><a href="#page-top">Hogar </a></li>
                <li class="sidebar-nav-item"><a href="#acerca">Acerca</a></li>
                <li class="sidebar-nav-item"><a href="#productos">Productos</a></li>
                <li class="sidebar-nav-item"><a href="#portfolio">Proyecto</a></li>
                    <li class="sidebar-nav-item"><a href="#explicacion">Explicacion</a></li>
                <li class="sidebar-nav-item"><a href="#contacto">Contacto</a></li>
            </ul>
        </nav>