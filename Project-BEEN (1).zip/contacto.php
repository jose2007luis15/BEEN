<section class="content-section bg-light" id="contacto">
 <h3>Información de contacto</h3>  
  <p>Contacto</p>
  <a href="mailto:been.com.co@gmail.com">
    click aqui para contactarnos.
  </a>
  <h3></h3>
   <div class="form-group">
  <form method="POST" action="index.php">
   <input type="text" name="nombre" class="form-control">
   <input type="email" name="correo" class="form-control">
    <textarea name="mensaje" class="form-control" cols="3" ,  rows="10" >
      
    </textarea>
    <button type="submit" class ="btn btn-ligth">Enviar</button>
    <button type="reset" class ="btn btn-ligth">Cancelar</button>
    <a href="calificaciones proyecto/">
      <button>Calificaciones del proyecto.</button>
    </a>
  </form>
  </div>
</section>