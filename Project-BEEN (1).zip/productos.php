<section class="content-section bg-primary text-white text-center" id="productos">
            <div class="container px-4 px-lg-5">
                <div class="content-section-heading">
                    <h3 class="text-secondary mb-0">Productos</h3>
                    <h2 class="mb-5">Productos de venta</h2>
                </div>
                <div class="row gx-4 gx-lg-5">
                    <div class="col-lg-3 col-md-6 mb-5 mb-lg-0">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">🎮</i></span>
                        <h4><strong>venta</strong></h4>
                        <p class="text-faded mb-0">¿Puedes comprar todos los artículos que hay en nuestra pagina!.</p>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-5 mb-lg-0">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">💻</i></span>
                        <h4><strong>servicio</strong></h4>
                        <p class="text-faded mb-0">¿Puedes subir artículos propios para que sean vendidos!</p>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-5 mb-md-0">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">🎊</i></span>
                        <h4><strong>consejo </strong></h4>
                        <p class="text-faded mb-0">
                            ¿Puedes darnos una calificacion de 0 a 10 de nuestros productos y su satisfaccion al comprar!.
                            <i class="fas fa-heart"></i>
                                                  </p>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">🤑</i></span>
                        <h4><strong>accion </strong></h4>
                        <p class="text-faded mb-0">¡Transacciones seguras y faciles de usar! </p>
                    </div>
                  </div>
                    <div class="col-lg-3 col-md-6">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">😎</i></span>
                        <h4><strong>empleo </strong></h4>
                        <p class="text-faded mb-0">Puedes subir todo lo que quieras y hacer tu propio emprendimiento en nuestra página.</p>
                    </div>
                </div>
            </div>
        </section>