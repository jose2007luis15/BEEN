<!DOCTYPE html>
<html lang="en"
    <? include 'head.php' ?>
    <body id="page-top">
      <? include 'menu.php' ?>
        <!-- Header-->
        <header class="masthead d-flex align-items-center">
            <div class="container px-4 px-lg-5 text-center">
                <h1 class="mb-1">BEEN</h1>
                <h3 class="mb-5"><em>¡Un mundo virtual más seguro!</em></h3>
                <a class="btn btn-primary btn-xl" href="#acerca">Acerca</a>
            </div>
        </header>
        <!-- About-->
         <?include 'acerca.php'?>
        <!-- Productos-->
       <?include 'productos.php'?>
        <!-- Callout-->
        <section class="callout">
            <div class="container px-4 px-lg-5  text-black text-center">
                <h2 class="mx-auto mb-5 ">
                    <em class="titulo">¡BIENVENIDOS A BEEN!</em>
                  <p class ="titulo">¡Una nueva experiencia!</p>  
              </div>
        </section>
        <!-- Portfolio-->
        <?include 'proyecto.php'?>
        <!-- Call to Action-->
        <section class="content-section bg-primary text-white">
            <div class="container px-4 px-lg-5 text-center">
                <h2 class="mb-4"></h2>
                <a class="btn btn-xl btn-light me-4" href="#!"</a>
             <a class="btn btn-xl btn-dark" href="#!"></a>
            </div>
        </section>
      <section id="interpretacion"></section>
      <h1></h1>
        <? include 'explicacion.php'?>
        <!-- contacto-->
        <? include 'contacto.php'?>
        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container px-4 px-lg-5">
                <ul class="list-inline mb-5">
                    <li class="list-inline-item">
                        <a class="social-link rounded-circle text-white mr-3" href="#!"><i class="icon-social-facebook"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a class="social-link rounded-circle text-white mr-3" href="#!"><i class="icon-social-twitter"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a class="social-link rounded-circle text-white" href="#!"><i class="icon-social-github"></i></a>
                    </li>
                </ul>
                <p class="text-muted small mb-0">BEEN.COM &copy;2023</p>
              <img src="imagenes/codigo1.png"width="28%" height="20%">
            </div>
        </footer>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>
        <!-- Bootstrap core JS-->
        <script 
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
